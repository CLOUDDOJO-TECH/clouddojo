"use client";
import ProjectDetailMultiStep from "./page-multi-step";

export default function ProjectDetailPage() {
  return <ProjectDetailMultiStep />;
}
