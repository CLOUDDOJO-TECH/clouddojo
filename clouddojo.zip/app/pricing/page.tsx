import { Pricing } from "@/components/landing/pricing/Pricing";

export default function PricingPage() {
  return <Pricing />;
}